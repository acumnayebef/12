import SwiftUI
import SpriteKit

// MARK: - App

@main
struct flappyberd: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}

struct GameView: View {
    var body: some View {
        SpriteKitContainer()
            .ignoresSafeArea()
    }
}

struct SpriteKitContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> SKView {
        GameSKView(frame: .zero)
    }

    func updateUIView(_ uiView: SKView, context: Context) {}
}

final class GameSKView: SKView {
    private var started = false

    override func layoutSubviews() {
        super.layoutSubviews()
        guard !started, bounds.width > 0, bounds.height > 0 else { return }
        started = true
        let scene = GameScene(size: bounds.size)
        scene.scaleMode = .resizeFill
        presentScene(scene)
    }
}



// MARK: - Game Scene

final class GameScene: SKScene, SKPhysicsContactDelegate {

    private enum Cat {
        static let bird: UInt32   = 1 << 0
        static let pipe: UInt32   = 1 << 1
        static let gap: UInt32    = 1 << 2
        static let ground: UInt32 = 1 << 3
    }

    private enum GameState { case ready, playing, over }

    // Настройки
    private let groundHeight: CGFloat = 90
    private let pipeWidth: CGFloat = 70
    private let pipeGap: CGFloat = 170
    private let pipeSpeed: CGFloat = 150      // пикселей в секунду
    private let pipeInterval: TimeInterval = 1.6
    private let flapVelocity: CGFloat = 420

    // Состояние
    private var state: GameState = .ready
    private var bird = SKShapeNode()
    private var pipes = SKNode()
    private var scoreLabel = SKLabelNode()
    private var messageLabel = SKLabelNode()
    private var score = 0
    private var best = UserDefaults.standard.integer(forKey: "flappy.best")

    // MARK: Setup

    override func didMove(to view: SKView) {
        setup()
    }

    private func setup() {
        removeAllChildren()
        removeAllActions()

        state = .ready
        score = 0
        backgroundColor = SKColor(red: 0.44, green: 0.78, blue: 0.93, alpha: 1)
        physicsWorld.gravity = CGVector(dx: 0, dy: -5.5)
        physicsWorld.contactDelegate = self

        pipes = SKNode()
        pipes.zPosition = 1
        addChild(pipes)

        setupGround()
        setupBird()
        setupLabels()
    }

    private func setupGround() {
        let ground = SKSpriteNode(
            color: SKColor(red: 0.87, green: 0.80, blue: 0.50, alpha: 1),
            size: CGSize(width: size.width, height: groundHeight)
        )
        ground.position = CGPoint(x: size.width / 2, y: groundHeight / 2)
        ground.zPosition = 5

        let body = SKPhysicsBody(rectangleOf: ground.size)
        body.isDynamic = false
        body.categoryBitMask = Cat.ground
        ground.physicsBody = body
        addChild(ground)

        // Полоска травы
        let grass = SKSpriteNode(
            color: SKColor(red: 0.45, green: 0.75, blue: 0.25, alpha: 1),
            size: CGSize(width: size.width, height: 14)
        )
        grass.position = CGPoint(x: 0, y: groundHeight / 2 - 7)
        grass.zPosition = 1
        ground.addChild(grass)
    }

    private func setupBird() {
        let radius: CGFloat = 16
        bird = SKShapeNode(circleOfRadius: radius)
        bird.fillColor = .yellow
        bird.strokeColor = .orange
        bird.lineWidth = 2
        bird.position = CGPoint(x: size.width * 0.3, y: size.height * 0.55)
        bird.zPosition = 10

        // Клюв
        let beak = SKShapeNode(rectOf: CGSize(width: 12, height: 7), cornerRadius: 2)
        beak.fillColor = .orange
        beak.strokeColor = .clear
        beak.position = CGPoint(x: radius, y: -2)
        bird.addChild(beak)

        // Глаз
        let eye = SKShapeNode(circleOfRadius: 4)
        eye.fillColor = .white
        eye.strokeColor = .black
        eye.lineWidth = 1
        eye.position = CGPoint(x: 6, y: 6)
        bird.addChild(eye)

        let body = SKPhysicsBody(circleOfRadius: radius - 2)
        body.isDynamic = false                 // пока не начали игру
        body.allowsRotation = false
        body.categoryBitMask = Cat.bird
        body.collisionBitMask = Cat.ground
        body.contactTestBitMask = Cat.pipe | Cat.gap | Cat.ground
        bird.physicsBody = body

        addChild(bird)
    }

    private func setupLabels() {
        scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
        scoreLabel.fontSize = 52
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: size.width / 2, y: size.height - 130)
        scoreLabel.zPosition = 100
        scoreLabel.text = "0"
        addChild(scoreLabel)

        messageLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
        messageLabel.fontSize = 28
        messageLabel.fontColor = .white
        messageLabel.numberOfLines = 0
        messageLabel.horizontalAlignmentMode = .center
        messageLabel.position = CGPoint(x: size.width / 2, y: size.height * 0.35)
        messageLabel.zPosition = 100
        messageLabel.text = "Tap to start"
        addChild(messageLabel)
    }

    // MARK: Game flow

    private func startGame() {
        state = .playing
        messageLabel.text = ""
        bird.physicsBody?.isDynamic = true
        flap()

        let spawn = SKAction.repeatForever(.sequence([
            .run { [weak self] in self?.spawnPipes() },
            .wait(forDuration: pipeInterval)
        ]))
        run(spawn, withKey: "spawn")
    }

    private func flap() {
        bird.physicsBody?.velocity = .zero
        bird.physicsBody?.velocity = CGVector(dx: 0, dy: flapVelocity)
    }

    private func spawnPipes() {
        let minY = groundHeight + pipeGap / 2 + 40
        let maxY = size.height - pipeGap / 2 - 40
        let gapCenterY = CGFloat.random(in: minY...maxY)

        let container = SKNode()
        container.position = CGPoint(x: size.width + pipeWidth, y: 0)

        let pipeColor = SKColor(red: 0.30, green: 0.69, blue: 0.31, alpha: 1)

        // Нижняя труба
        let bottomHeight = gapCenterY - pipeGap / 2 - groundHeight
        let bottom = SKSpriteNode(color: pipeColor, size: CGSize(width: pipeWidth, height: bottomHeight))
        bottom.anchorPoint = CGPoint(x: 0.5, y: 0)
        bottom.position = CGPoint(x: 0, y: groundHeight)
        let bBody = SKPhysicsBody(rectangleOf: bottom.size, center: CGPoint(x: 0, y: bottomHeight / 2))
        bBody.isDynamic = false
        bBody.categoryBitMask = Cat.pipe
        bottom.physicsBody = bBody
        container.addChild(bottom)

        // Верхняя труба
        let topHeight = size.height - (gapCenterY + pipeGap / 2)
        let top = SKSpriteNode(color: pipeColor, size: CGSize(width: pipeWidth, height: topHeight))
        top.anchorPoint = CGPoint(x: 0.5, y: 1)
        top.position = CGPoint(x: 0, y: size.height)
        let tBody = SKPhysicsBody(rectangleOf: top.size, center: CGPoint(x: 0, y: -topHeight / 2))
        tBody.isDynamic = false
        tBody.categoryBitMask = Cat.pipe
        top.physicsBody = tBody
        container.addChild(top)

        // Невидимая зона для подсчёта очков
        let sensor = SKNode()
        sensor.position = CGPoint(x: 0, y: gapCenterY)
        let sBody = SKPhysicsBody(rectangleOf: CGSize(width: 4, height: pipeGap))
        sBody.isDynamic = false
        sBody.categoryBitMask = Cat.gap
        sBody.collisionBitMask = 0
        sensor.physicsBody = sBody
        container.addChild(sensor)

        pipes.addChild(container)

        let distance = size.width + pipeWidth * 2
        container.run(.sequence([
            .moveBy(x: -distance, y: 0, duration: TimeInterval(distance / pipeSpeed)),
            .removeFromParent()
        ]))
    }

    private func gameOver() {
        guard state == .playing else { return }
        state = .over
        removeAction(forKey: "spawn")
        pipes.children.forEach { $0.removeAllActions() }

        if score > best {
            best = score
            UserDefaults.standard.set(best, forKey: "flappy.best")
        }
        messageLabel.text = "Game Over\nScore: \(score)  Best: \(best)\nTap to restart"

        // Небольшая тряска экрана
        let shake = SKAction.sequence([
            .moveBy(x: 8, y: 0, duration: 0.04),
            .moveBy(x: -16, y: 0, duration: 0.04),
            .moveBy(x: 8, y: 0, duration: 0.04)
        ])
        run(shake)
    }

    // MARK: Input

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        switch state {
        case .ready:   startGame()
        case .playing: flap()
        case .over:    setup()
        }
    }

    // MARK: Physics

    func didBegin(_ contact: SKPhysicsContact) {
        guard state == .playing else { return }
        let mask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask

        if mask & Cat.gap != 0 {
            score += 1
            scoreLabel.text = "\(score)"
        } else if mask & (Cat.pipe | Cat.ground) != 0 {
            gameOver()
        }
    }

    // MARK: Update

    override func update(_ currentTime: TimeInterval) {
        guard let body = bird.physicsBody else { return }

        // Наклон птицы по скорости
        if state != .ready {
            let angle = max(-1.2, min(0.5, body.velocity.dy / 800))
            bird.zRotation = angle
        }

        // Потолок
        if bird.position.y > size.height {
            bird.position.y = size.height
            body.velocity.dy = 0
        }
    }
}
